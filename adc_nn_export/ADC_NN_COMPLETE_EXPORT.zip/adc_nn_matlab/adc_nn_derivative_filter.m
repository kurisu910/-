function h = adc_nn_derivative_filter(taps, passband)
% Odd, antisymmetric least-squares FIR differentiator, d/d(sample index).
% This coefficient design is an implementation choice, not authors' coefficients.
assert(mod(taps,2)==1 && taps>=3 && passband>0 && passband<1);
persistent lastTaps lastBand lastH
if isequal(taps,lastTaps) && isequal(passband,lastBand)
    h = lastH; return;
end
p = (taps-1)/2;
k = 1:p;
w = linspace(1e-5,passband*pi,max(512,4*p))';
g = (2*sin(w*k))\w;
h = [flipud(g);0;-g]';
lastTaps=taps; lastBand=passband; lastH=h;
end
