function summary = adc_nn_evaluate(model, r, plotResult)
if nargin<3, plotResult=true; end
out = adc_nn_predict(model,r);
% Identical window and samples before/after; omit label-filter edge region too.
p = (model.cfg.labelTaps-1)/2;
valid = out.index>p & out.index<=numel(r.d)-p;
assert(sum(valid)>=128, 'Test record too short.');
raw = out.dRaw(valid); cal = out.dCal(valid);
summary.before = adc_nn_metrics(raw,r.fs,r.fin);
summary.after = adc_nn_metrics(cal,r.fs,r.fin);
summary.deltaSNDR = summary.after.SNDR_dB-summary.before.SNDR_dB;
summary.deltaSFDR = summary.after.SFDR_dB-summary.before.SFDR_dB;
fprintf('%s: SNDR %.2f -> %.2f dB; SFDR %.2f -> %.2f dB\n',r.id, ...
    summary.before.SNDR_dB,summary.after.SNDR_dB, ...
    summary.before.SFDR_dB,summary.after.SFDR_dB);
if plotResult
    N = numel(raw); n=(0:N-1)'; w=0.5-0.5*cos(2*pi*n/N);
    f=(0:floor(N/2))*r.fs/N/1e6;
    a=abs(fft((raw(:)-mean(raw)).*w))*2/sum(w);
    b=abs(fft((cal(:)-mean(cal)).*w))*2/sum(w);
    reference=max(a(2:floor(N/2)+1));
    figure; plot(f,20*log10(max(a(1:numel(f))/reference,1e-12))); hold on;
    plot(f,20*log10(max(b(1:numel(f))/reference,1e-12)));
    grid on; xlabel('Frequency (MHz)'); ylabel('Amplitude (dBc, raw reference)');
    legend('Before','After'); title(r.id,'Interpreter','none');
end
end
