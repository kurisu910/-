function [model, history, results] = run_virtuoso_data(manifestPath)
% manifest columns: file,id,split,fin_Hz,temperature_C
% split: train,validation,test (single tone; use direct API for two-tone tests).
% waveform CSV: time_s,vp_v,vn_v, one held sample/cycle, after startup removal.
% Filenames resolve relative to the manifest directory.
cfg=adc_nn_user_config();
% User OUTPUT differential full scale is [-0.6,+0.6) V; INPUT is 0.6 Vpp.
if nargin<1, manifestPath='manifest.csv'; end
tab=readtable(manifestPath);
required={'file','id','split','fin_Hz','temperature_C'};
assert(all(ismember(required,tab.Properties.VariableNames)), 'Invalid manifest columns.');
base=fileparts(manifestPath); if isempty(base), base=pwd; end
train=[]; validation=[]; test=[];
for i=1:height(tab)
    file=fullfile(base,char(string(tab.file(i))));
    id=char(string(tab.id(i)));
    r=adc_nn_load_csv(file,tab.fin_Hz(i),tab.temperature_C(i),cfg,id);
    split=char(string(tab.split(i)));
    switch split
        case 'train', train=append_record(train,r);
        case 'validation', validation=append_record(validation,r);
        case 'test', test=append_record(test,r);
        otherwise, error('Unknown split: %s',split);
    end
end
assert(~isempty(test), 'Add at least one independent test record.');
ids=[{train.id},{validation.id},{test.id}];
assert(numel(unique(ids))==numel(ids), 'All record IDs must be unique.');
[model,history]=adc_nn_train(train,validation,cfg);
results=cell(1,numel(test));
for i=1:numel(test), results{i}=adc_nn_evaluate(model,test(i),true); end
save('virtuoso_adc_nn_model.mat','model','history','results','tab');
end

function records=append_record(records,r)
if isempty(records), records=r; else, records(end+1)=r; end
end
