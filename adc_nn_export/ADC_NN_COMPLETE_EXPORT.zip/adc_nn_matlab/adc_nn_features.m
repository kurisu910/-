function [X, idx] = adc_nn_features(r, cfg)
% Columns are samples; rows are [d,d',d'd,...,d'd^5,T].
% Derivative is per sample, NOT per second: prevents a 1e9 scaling factor.
assert(r.fs==cfg.fs && r.vmin==cfg.vmin && r.vmax==cfg.vmax && ...
    r.bits==cfg.bits && r.quantized==cfg.quantize, 'Record/config mismatch.');
h = adc_nn_derivative_filter(cfg.derivativeTaps,cfg.derivativeBand);
p = (numel(h)-1)/2;
d = r.d;
assert(numel(d)>2*p+1);
dd = conv(d,h,'same'); % centered offline FIR; streaming equivalent delays d by p.
X = [d;dd;dd.*d;dd.*d.^2;dd.*d.^3;dd.*d.^4;dd.*d.^5; ...
    r.temperature*ones(1,numel(d))];
idx = (p+1):(numel(d)-p); % discard FIR boundary artifacts.
X = X(:,idx);
end
