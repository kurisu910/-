function r = adc_nn_record(time_s, vp_v, vn_v, temperature_C, fin_Hz, cfg, id)
% Input: ONE settled held-voltage sample per clock cycle, after warm-up.
% fin_Hz is scalar for training, or a vector of tones for test-only records.
t = double(time_s(:)); vp = double(vp_v(:)); vn = double(vn_v(:));
assert(numel(t)==numel(vp) && numel(t)==numel(vn), 'Length mismatch.');
assert(numel(t)>=128 && all(isfinite([t;vp;vn])), 'Invalid/short waveform.');
assert(all(diff(t)>0), 'Sample times must increase strictly.');
assert(max(abs(diff(t)*cfg.fs-1)) < 1e-4, ...
    'Expected one uniformly spaced sample per cycle at cfg.fs.');
assert(isscalar(temperature_C) && isfinite(temperature_C), ...
    'Use one constant temperature per record.');
assert(~isempty(fin_Hz) && all(isfinite(fin_Hz)) && ...
    all(fin_Hz>0) && all(fin_Hz<cfg.fs/2), 'Use baseband tones below Nyquist.');
assert(cfg.vmax>cfg.vmin && cfg.bits>=1 && cfg.bits<=24 && ...
    cfg.bits==round(cfg.bits), 'Invalid range or bit depth.');
v = vp-vn;
outside = (v<cfg.vmin) | (v>=cfg.vmax);
assert(~any(outside), ...
    'Held voltage exceeds differential full scale. Fix range or amplitude.');
if cfg.quantize
    q = (cfg.vmax-cfg.vmin)/2^cfg.bits;
    code = floor((v-cfg.vmin)/q);
    vq = cfg.vmin + (code+0.5)*q; % mid-rise ideal quantizer, midpoint decoding.
else
    code = [];
    vq = v;
end
center = (cfg.vmax+cfg.vmin)/2;
halfRange = (cfg.vmax-cfg.vmin)/2;
r = struct('id',char(id),'time',t,'d',((vq-center)/halfRange)', ...
    'temperature',double(temperature_C),'fin',double(fin_Hz(:)'), ...
    'fs',cfg.fs,'vmin',cfg.vmin,'vmax',cfg.vmax,'bits',cfg.bits, ...
    'quantized',cfg.quantize,'codes',code);
end
