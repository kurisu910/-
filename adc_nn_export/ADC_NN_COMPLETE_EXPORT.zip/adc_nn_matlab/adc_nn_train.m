function [model, history] = adc_nn_train(trainRecords, validationRecords, cfg)
% Deep Learning Toolbox: dlarray/dlfeval/dlgradient/adamupdate custom loop.
% Splits MUST be separate waveforms/conditions, not random points from one sine.
assert(exist('dlarray','file')~=0, 'Deep Learning Toolbox is required to train.');
assert(~isempty(trainRecords) && ~isempty(validationRecords));
ids = [{trainRecords.id},{validationRecords.id}];
assert(numel(unique(ids))==numel(ids), 'Train/validation record IDs must differ.');
[Xt,Yt] = assemble(trainRecords,cfg);
[Xv,Yv] = assemble(validationRecords,cfg);
rng(cfg.seed,'twister');
mu = mean(Xt,2); sigma = std(Xt,0,2);
sigma(sigma<1e-10) = 1; % constant-temperature runs remain possible.
errorScale = max(std(Yt,0,2),1e-6);
Xt = (Xt-mu)./sigma; Xv = (Xv-mu)./sigma;
Yt = Yt/errorScale; Yv = Yv/errorScale;
% Warm start the linear path with a weak ridge regression.
A = [Xt;ones(1,size(Xt,2))];
ridge = 1e-4*eye(size(A,1)); ridge(end,end) = 0;
beta = (A*A'+ridge)\(A*Yt');
p.W = dlarray(single(0.3*randn(3,8)));
p.b = dlarray(single(0.1*randn(3,1)));
p.v = dlarray(single(0.01*randn(3,1)));
p.a = dlarray(single(beta(1:8)));
p.c = dlarray(single(beta(9)));
Xt = single(Xt); Xv = single(Xv); Yt = single(Yt); Yv = single(Yv);
avg = []; avgSq = []; iteration = 0;
initialVal = mean((double(extractdata(adc_nn_forward(p,dlarray(Xv))))-double(Yv)).^2);
bestLoss = initialVal; best = p; bestEpoch = 0; stale = 0;
history.train = nan(cfg.epochs,1); history.validation = history.train;
history.initialValidationMSE = initialVal*errorScale^2;
for epoch = 1:cfg.epochs
    order = randperm(size(Xt,2));
    for first = 1:cfg.batchSize:numel(order)
        j = order(first:min(first+cfg.batchSize-1,numel(order)));
        [loss,grad] = dlfeval(@gradients,p,dlarray(Xt(:,j)),dlarray(Yt(:,j)),cfg.l2);
        assert(isfinite(double(extractdata(loss))), 'Non-finite loss; inspect data/scales.');
        iteration = iteration+1;
        [p,avg,avgSq] = adamupdate(p,grad,avg,avgSq,iteration,cfg.learningRate);
    end
    yp = double(extractdata(adc_nn_forward(p,dlarray(Xt))));
    yv = double(extractdata(adc_nn_forward(p,dlarray(Xv))));
    tr = mean((yp-double(Yt)).^2); va = mean((yv-double(Yv)).^2);
    assert(isfinite(tr) && isfinite(va), 'Non-finite epoch loss.');
    history.train(epoch) = tr*errorScale^2;
    history.validation(epoch) = va*errorScale^2;
    if va<bestLoss
        bestLoss=va; best=p; bestEpoch=epoch; stale=0;
    else
        stale=stale+1;
    end
    if cfg.verbose && (epoch==1 || mod(epoch,10)==0)
        fprintf('epoch %3d: train MSE %.3g; validation MSE %.3g\n', ...
            epoch,history.train(epoch),history.validation(epoch));
    end
    if stale>=cfg.patience, break; end
end
history.train = history.train(1:epoch);
history.validation = history.validation(1:epoch);
history.bestEpoch = bestEpoch;
names = fieldnames(best);
for i=1:numel(names), best.(names{i})=double(extractdata(best.(names{i}))); end
model = struct('parameters',best,'featureMean',mu,'featureScale',sigma, ...
    'errorScale',errorScale,'cfg',cfg,'trainingIDs',{{trainRecords.id}}, ...
    'validationIDs',{{validationRecords.id}},'parameterCount',39, ...
    'temperatureRange',[min([trainRecords.temperature]),max([trainRecords.temperature])]);
end

function [loss,g] = gradients(p,X,Y,l2)
pred = adc_nn_forward(p,X);
loss = mean((pred-Y).^2,'all') + l2*(sum(p.W.^2,'all')+sum(p.v.^2,'all')+sum(p.a.^2,'all'));
g = dlgradient(loss,p);
end

function [X,Y] = assemble(records,cfg)
xx = cell(1,numel(records)); yy = xx;
for i=1:numel(records)
    [feat,featureIdx] = adc_nn_features(records(i),cfg);
    [target,labelIdx] = adc_nn_label(records(i),cfg);
    [idx,pos] = intersect(featureIdx,labelIdx,'stable');
    xx{i} = feat(:,pos); yy{i} = target(idx);
end
X = cat(2,xx{:}); Y = cat(2,yy{:});
assert(all(isfinite(X(:))) && all(isfinite(Y(:))), 'Non-finite training data.');
end
