function [vp, vn] = adc_nn_sample_waveform(t, vpContinuous, vnContinuous, sampleTimes)
% Extract held values from a dense Virtuoso transient waveform.
% Choose sampleTimes in the settled HOLD phase; never interpolate across an edge.
t = double(t(:)); ts = double(sampleTimes(:));
assert(numel(t)==numel(vpContinuous) && numel(t)==numel(vnContinuous), ...
    'Transient waveform lengths differ.');
assert(all(isfinite([t;vpContinuous(:);vnContinuous(:);ts])) && ...
    all(diff(t)>0) && all(diff(ts)>0), 'Invalid waveform time axis.');
assert(all(ts>=t(1) & ts<=t(end)), 'Sample times outside transient waveform.');
vp = interp1(t,double(vpContinuous(:)),ts,'linear');
vn = interp1(t,double(vnContinuous(:)),ts,'linear');
end
