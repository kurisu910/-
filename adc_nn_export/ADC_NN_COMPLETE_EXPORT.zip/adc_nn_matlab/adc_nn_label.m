function [target, idx, reference] = adc_nn_label(r, cfg)
% Paper Fig.4 idea: d - fundamental-bandpass(d), MSE target.
% Training ONLY. The inference routine never calls this function.
assert(isscalar(r.fin), 'Only single-tone records can form training labels.');
assert(mod(cfg.labelTaps,2)==1 && cfg.labelTaps>=3);
f0 = r.fin; fs = cfg.fs; N = numel(r.d);
assert(N>=4*cfg.labelTaps, 'Use at least 4*labelTaps held samples.');
assert(f0<cfg.derivativeBand*fs/2, 'Tone exceeds derivative design passband.');
bw = cfg.labelHalfWidthHz;
assert(bw>0 && f0-bw>0 && f0+bw<fs/2, 'Invalid label passband.');
p = (cfg.labelTaps-1)/2;
k = -p:p;
fl = (f0-bw)/fs; fh = (f0+bw)/fs;
h = zeros(size(k)); z = k~=0;
h(z) = (sin(2*pi*fh*k(z))-sin(2*pi*fl*k(z)))./(pi*k(z));
h(~z) = 2*(fh-fl);
h = h.*(0.54+0.46*cos(pi*k/p)); % Hamming, symmetric centered FIR.
H0 = sum(h.*cos(2*pi*f0/fs*k));
assert(H0>1e-8, 'Degenerate label bandpass.');
h = h/H0; % unity gain at known fundamental, zero phase after delay alignment.
% Reject aliases of HD2...HD5 that cannot be separated from the fundamental.
for order = 2:5
    fa = abs(mod(order*f0+fs/2,fs)-fs/2);
    Ha = abs(sum(h.*exp(-1i*2*pi*fa/fs*k)));
    assert(Ha<0.01, ...
        'An aliased harmonic falls in/near label passband. Change fin or labelTaps.');
end
dc = mean(r.d);
reference = dc + conv(r.d-dc,h,'same');
target = r.d-reference;
idx = (p+1):(N-p); % compensate delay with centered filtering, discard both ends.
end
