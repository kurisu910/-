function m = adc_nn_metrics(d, fs, tones_Hz)
% Diagnostic single-/multi-tone metrics; no Signal Processing Toolbox needed.
% SNDR uses time-domain residual after joint DC + fundamental least-squares fit.
% SFDR uses largest Hann-window residual FFT spur vs largest fitted tone.
% This is a documented diagnostic estimator, not the authors' measurement code.
d = double(d(:)); N = numel(d); n = (0:N-1)';
assert(N>=128 && all(isfinite(d)) && all(tones_Hz>0 & tones_Hz<fs/2));
B = ones(N,1);
for f = tones_Hz(:)'
    B = [B,sin(2*pi*f/fs*n),cos(2*pi*f/fs*n)]; %#ok<AGROW>
end
assert(rank(B)==size(B,2), 'Tones are unresolved/duplicate.');
coef = B\d;
signal = B(:,2:end)*coef(2:end);
residual = d-B*coef;
m.SNDR_dB = 10*log10(mean(signal.^2)/max(mean(residual.^2),realmin));
amp = hypot(coef(2:2:end),coef(3:2:end));
w = 0.5-0.5*cos(2*pi*n/N);
s = abs(fft(residual.*w))*2/sum(w);
s = s(1:floor(N/2)+1); s(1)=0;
if mod(N,2)==0, s(end)=s(end)/2; end
m.SFDR_dB = 20*log10(max(amp)/max(max(s),realmin));
m.fundamentalAmplitude = amp;
m.tonePower = mean(signal.^2);
m.residualPower = mean(residual.^2);
m.ENOB = (m.SNDR_dB-1.76)/6.02; % conventional single-tone formula only.
if numel(tones_Hz)>1, m.ENOB=NaN; end
m.samples = N;
end
