function y = adc_nn_forward(p, X)
% 3 nonlinear tanh units + a linear branch + a linear combining output.
% s1 output gain is folded into a: same function class, fewer redundant parameters.
y = p.v'*tanh(p.W*X+p.b) + p.a'*X + p.c;
end
