function [model, history, results] = demo_adc_nn()
% Synthetic RC sampler data checks the pipeline; NOT a Virtuoso simulation
% and NOT a reproduction of the paper's measured improvement.
cfg = adc_nn_config();
rng(cfg.seed,'twister');
N = 8192;
bins = [701,1231,2003];
amps = [0.45,0.8]; temperatures = [-20,80];
train = []; count=0;
for temp=temperatures
    for amplitude=amps
        for bin=bins
            count=count+1;
            r=synthetic_record(bin*cfg.fs/N,amplitude,temp,N,cfg, ...
                sprintf('train_%02d',count));
            if isempty(train), train=r; else, train(end+1)=r; end %#ok<AGROW>
        end
    end
end
validation=synthetic_record(1601*cfg.fs/N,0.65,25,N,cfg,'validation');
test=synthetic_record(1777*cfg.fs/N,0.72,40,N,cfg,'test_unseen');
twoTone=synthetic_record([1373,1699]*cfg.fs/N,[0.35,0.35],40,N,cfg,'test_two_tone');
[model,history]=adc_nn_train(train,validation,cfg);
results.single=adc_nn_evaluate(model,test,true);
results.twoTone=adc_nn_evaluate(model,twoTone,true);
figure; semilogy(history.train); hold on; semilogy(history.validation);
xlabel('Epoch'); ylabel('Error MSE (normalized ADC units squared)');
legend('Train','Validation'); grid on;
save('demo_adc_nn_model.mat','model','history','results');
end

function r=synthetic_record(fin,amplitude,temp,N,cfg,id)
% Forward first-order nonlinear RC track-and-hold, with history across holds.
% Selected toy parameters illustrate the mechanism; not authors' transistor data.
warmup=256; count=N+warmup; substeps=32;
trackDuty=0.5; dt=trackDuty/cfg.fs/substeps;
v=0; held=zeros(count,1); t=(0:count-1)'/cfg.fs;
for n=1:count
    for j=1:substeps
        u=t(n)-trackDuty/cfg.fs+(j-0.5)*dt;
        vin=sum(amplitude.*sin(2*pi*fin*u+0.23));
        tau=(0.025/cfg.fs)*(1+0.7*exp(-(temp-25)/110)*vin^2);
        v=vin+(v-vin)*exp(-dt/tau);
    end
    held(n)=v;
end
held=held(warmup+1:end); t=t(warmup+1:end);
% independent small noise; differential midpoint is the cfg range midpoint.
held=held+2e-5*randn(size(held));
vd=(cfg.vmax+cfg.vmin)/2+(cfg.vmax-cfg.vmin)/2*held;
vp=0.5+vd/2; vn=0.5-vd/2;
r=adc_nn_record(t,vp,vn,temp,fin,cfg,id);
end
