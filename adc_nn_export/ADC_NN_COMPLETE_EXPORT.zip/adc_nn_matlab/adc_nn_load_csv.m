function r = adc_nn_load_csv(path, fin_Hz, temperature_C, cfg, id)
% CSV columns: time_s,vp_v,vn_v. Already one HOLD sample per cycle.
tab = readtable(path);
assert(all(ismember({'time_s','vp_v','vn_v'},tab.Properties.VariableNames)), ...
    'CSV must contain time_s,vp_v,vn_v. See README for raw transient export.');
r = adc_nn_record(tab.time_s,tab.vp_v,tab.vn_v,temperature_C,fin_Hz,cfg,id);
end
