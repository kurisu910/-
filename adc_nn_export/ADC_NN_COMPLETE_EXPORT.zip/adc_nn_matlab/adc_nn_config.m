function cfg = adc_nn_config()
% Defaults for a 1-GS/s differential sampling circuit.
% Supply the DIFFERENTIAL input limits, not the common-mode supply rails.
cfg.fs = 1e9;
cfg.bits = 12;
cfg.vmin = -0.5;               % Example only: replace with your input range.
cfg.vmax =  0.5;
cfg.quantize = true;           % false if voltages already represent ADC codes.
cfg.derivativeTaps = 17;
cfg.derivativeBand = 0.8;      % fraction of Nyquist; 0.8 means 400 MHz here.
cfg.labelTaps = 1025;
cfg.labelHalfWidthHz = 5e6;    % training-only fundamental bandpass.
cfg.seed = 42;
cfg.epochs = 200;
cfg.batchSize = 2048;
cfg.learningRate = 2e-3;
cfg.l2 = 1e-5;
cfg.patience = 30;
cfg.verbose = true;
end
