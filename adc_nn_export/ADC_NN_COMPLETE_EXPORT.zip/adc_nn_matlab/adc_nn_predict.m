function out = adc_nn_predict(model, r)
% Fixed coefficients; no target filter, no fin-dependent correction, no retraining.
[X,idx] = adc_nn_features(r,model.cfg);
Xs = (X-model.featureMean)./model.featureScale;
e = model.errorScale*adc_nn_forward(model.parameters,Xs);
out.index = idx;
out.time = r.time(idx);
out.dRaw = r.d(idx);
out.error = e;
out.dCal = out.dRaw-e;
center = (model.cfg.vmax+model.cfg.vmin)/2;
halfRange = (model.cfg.vmax-model.cfg.vmin)/2;
out.vCal = center+halfRange*out.dCal;
% Keep fractional corrected codes; DO NOT requantize or clip correction outputs.
out.correctedCode = (out.vCal-model.cfg.vmin)/ ...
    ((model.cfg.vmax-model.cfg.vmin)/2^model.cfg.bits)-0.5;
end
