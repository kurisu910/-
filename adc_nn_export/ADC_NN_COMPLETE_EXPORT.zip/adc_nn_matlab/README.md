# 差分采样网络的浅层 NN 后校正（MATLAB）

依据 Molendijk 等，TCAS-I 2026，DOI: 10.1109/TCSI.2025.3645475。
针对你已有的 **1 GS/s 差分晶体管级采样网络**准备。需要 MATLAB（建议 R2021b 或更新）和 Deep Learning Toolbox；不需要 Signal Processing Toolbox。

迁移到其他 Codex 环境时，先阅读 `CODEX_HANDOFF.md`，其中包含完整背景、当前状态和后续任务；同时携带代码 ZIP 和原论文 PDF。

这是依据论文写的独立实现，不是作者代码。保留式（6）特征、3 个 tanh 单元、线性支路、误差学习和 MSE；没有实现作者反复训练/剪枝得到的对称权重约束，也没有复用原芯片数据或权重。导数 FIR 系数、带通 FIR、归一化、Adam 参数及线性预初始化是这里的实现选择。

## 先跑代码

解压后进入这个文件夹：

```matlab
[model, history, results] = demo_adc_nn;
```

演示使用独立的非线性 RC 跟踪保持模型，单音训练、另一组条件验证和测试，再测试双音。演示结果只证明流程在合成数据上的表现，不能用作你的 Virtuoso 电路结果或论文实测复现结果。第一轮结束后保存 `demo_adc_nn_model.mat`。

**验证状态：当前执行环境没有 MATLAB。已在 NumPy 中验证对应的滤波、标签、量化、梯度和训练数学流程，并在公开 MATLAB 语法解析器中检查 .m 文件；尚未在 MATLAB/Deep Learning Toolbox 实际执行。你的首次 demo 是最终的运行兼容性检查。** 详细检查记录见 VALIDATION.md。图文说明有 PDF 和可直接在浏览器打开的 HTML 两个版本。

## 已按你回复补充的实际电路配置

`adc_nn_user_config.m` 与真实数据入口 `run_virtuoso_data.m` 已使用：

- fs = 1 GHz；差分输入满量程 0.6 Vpp，差分输出满量程 1.2 Vpp。
- 量化的是 **输出** Vp−Vn，因此使用输出范围 [-0.6,+0.6) V，量化步长约 292.969 μV。假设输出差分信号以 0 V 为中心；共模为 0.5 V。请确认 Vp−Vn 的真实定义，不能将单端摆幅再重复加倍。
- 温度先取 25°C；输入频率 127*1e9/256 = 496.09375 MHz。
- 输入与输出相差 2 倍的增益关系不会由基波标签恢复/消除；它属于信号路径的增益定义。

**该频率非常接近 Nyquist。** 原默认 17-tap 导数滤波器在这个点只保留约 6.18% 的理想导数幅度，不能直接使用。用户配置改成 513 taps、0.995×Nyquist 的最小二乘导数滤波器（数值检查在该点约 0.044% 幅度误差），标签带通半宽改为 0.75 MHz，避免跨过 Nyquist 边界。这是适配你电路条件的算法实验，**不再对应论文 17-tap 的硬件成本/延迟**；中心滤波对应 256 个采样周期因果延迟。

第一轮只做一个频率、不同幅度的验证：复制 `manifest_user_496MHz.csv` 并填写真实 CSV 路径。

```matlab
[model, history, results] = run_virtuoso_data('manifest_user_496MHz.csv');
```

训练幅度比例建议 45%、65%、85%；验证 70%；测试 80%。这些比例以 0.6 Vpp 的差分输入满量程计算，分别为 0.27、0.39、0.51、0.42、0.48 Vpp。预计输出摆幅为其两倍，实际用晶体管仿真结果确认。保留余量，先不要用 100% 满幅。

8192 点窗口包含整数 4064 个输入周期；仍应丢弃启动过程，不能只导出 256 点。对应实际电路操作的初学说明见图文说明第 9 部分。

**这一轮只证明固定频率下的幅度泛化，不能证明频率、温度或双音泛化。** 此时运行 demo 的低频宽条件数据，使用的是 adc_nn_config 的通用 17-tap 配置，不是用户近 Nyquist 配置。成功后需要补其他频率/双音数据并重新训练，且近 Nyquist 时数字导数在实际电路上是否足以描述误差，仍需测试。

## 对接 Virtuoso

整个流程是：连续时间差分开关电容网络 → 每个周期取一次保持电压 → 可选理想量化 → 特征 → NN 预测误差 → 减去误差。

### 1. 先确认量化满量程

真实数据使用 `adc_nn_user_config.m` 中的 `vmin/vmax`。它们是 **vp-vn 的差分输出范围**，不是输入摆幅、VDD 或共模。通用演示的 `adc_nn_config.m` 仍使用 `[-0.5,+0.5)` V 占位范围；接用户数据应使用用户配置。12 bit 与论文一致，可以更改。

如果你只有开关电容网络，没有后续 ADC，用 `cfg.quantize=true` 增加理想量化。若数据已经包含 ADC 量化，不应再次量化；把数字码按原转换关系还原为电压，设置 `false`。不同设置需要重新训练。校准结果保留小数精度，不重新舍入到 12 bit。

### 2. 取样位置

每个周期在 **相同且已经稳定的保持相位**读取 vp、vn，1 GS/s 的周期为 1 ns。先丢弃启动过程；不要在时钟翻转瞬间、开关仍导通的跟踪相位、毛刺期间取值。

若导出的是密集 transient 波形，可用：

```matlab
% t, vp, vn 来自 transient 导出；tSample 是你按实际时钟定义的保持取样时刻。
% 这里的 t0/holdOffset 必须自己按电路时钟设置，不在库里猜测。
tSample = t0 + holdOffset + (0:8191)'/cfg.fs;
[vpHeld, vnHeld] = adc_nn_sample_waveform(t, vp, vn, tSample);
r = adc_nn_record(tSample, vpHeld, vnHeld, 25, fin, cfg, 'train_01');
```

函数线性插值，要求原始时间轴递增、不重复、取样时刻在数据范围内。确保取样点周围 transient 步长足够细；插值跨越时钟边沿会制造假误差。传进训练函数的是每周期一个样本，不是所有 transient 点。

### 3. 建立 CSV 和 manifest

每条波形 CSV 列为：

```text
time_s,vp_v,vn_v
```

单位分别为秒和伏特。每份文件包含一个输入条件，至少 4096 个有效保持样本，建议 8192 或 16384。输入频率和温度写在 manifest 里。针对你的近 Nyquist 首轮实验，填写 `manifest_user_496MHz.csv` 的真实文件路径后运行；通用的 `manifest_template.csv` 仅作为低频多条件实验的参考：

```matlab
[model, history, results] = run_virtuoso_data('manifest_user_496MHz.csv');
```

也可不使用 CSV：

```matlab
cfg = adc_nn_user_config(); % 你的实际输出范围及近 Nyquist 配置。
% 每个 r 都来自一份独立的单音 waveform：
r1 = adc_nn_record(t1, vp1, vn1, 25, f1, cfg, 'train_1');
r2 = adc_nn_record(t2, vp2, vn2, 25, f2, cfg, 'train_2');
rv = adc_nn_record(tv, vpv, vnv, 25, fv, cfg, 'validation');
rt = adc_nn_record(tt, vpt, vnt, 25, ft, cfg, 'test');
[model, history] = adc_nn_train([r1,r2], rv, cfg);
out = adc_nn_predict(model, rt);
report = adc_nn_evaluate(model, rt, true);
save('my_adc_calibrator.mat','model','history');
```

`out.dRaw/dCal` 是归一化数字信号；`out.vCal` 是差分等效电压；`out.correctedCode` 可以有小数。`out.index/time` 对应原记录中保留的样本。

## 第一轮建议的数据量

先固定温度 25°C，选择 3 个输入频率 × 2 个幅度，得到 6 条训练记录；另用 1 条不同频率/幅度记录作验证、1 条作最终测试。幅度可取差分满量程正弦峰值的 45%、80%，并留出失真和噪声余量。

1 GS/s、8192 点时，建议使用相干采样频率 `fin=k*fs/N`：

| 用途 | k | fin |
|---|---:|---:|
| train | 701 | 85.5712890625 MHz |
| train | 1231 | 150.2685546875 MHz |
| train | 2003 | 244.5068359375 MHz |
| validation | 1601 | 195.4345703125 MHz |
| test | 1777 | 216.9189453125 MHz |

相干采样不是带通标签的硬性要求，但能减少谱泄漏，便于检查。不推荐用精确 fs/4、fs/3 等频率做首轮实验：某些高次谐波可能混叠到基波而无法由带通标签分离。程序检查 HD2–HD5 的带通抑制；其余高阶也要在频谱中人工确认。

确认固定温度校准有效后，再增加低温/高温数据和独立温度测试；只训练 25°C 时，不能声称温度泛化。测试记录不能随机从同一训练正弦里抽点，验证和最终测试也要分开。

双音只用于测试，输入总峰值不超满量程：

```matlab
rTwo = adc_nn_record(t, vp, vn, 25, [fA,fB], cfg, 'two_tone_test');
reportTwo = adc_nn_evaluate(model, rTwo, true);
```

## 网络与标签

输入共 8 维：`[d,d',d'd,d'd^2,d'd^3,d'd^4,d'd^5,T]`。
式（6）的 `d'` 用 17-tap 反对称 FIR 得到，单位是每采样点变化量；标准化参数只从训练数据计算，并固定用于验证/推理。

网络为：

```text
e_normalized = v' * tanh(W*X+b) + a'*X + c
e = errorScale * e_normalized
d_cal = d - e
```

3 个 tanh 单元对应 s2/s3/s4，`a'*X` 是 s1 线性支路，最后的加权求和对应 s5。把 s1 的输出增益折入 a，不改变函数表达能力，共 39 个参数。没有温度变化时，T 仍是输入，但对应系数不能学到温度依赖。

训练标签遵循论文 Fig. 4：对 **量化后的**单音 d 做只保留基波的带通滤波，`target=d-reference`，MSE+很小的 L2。带通系数归一化到已知基波频率的单位增益，且通过中心卷积补偿群延迟；裁掉滤波边界。标签仅保留原波形 DC 和基波，不能恢复原 ADC 的绝对增益/相位误差。随机噪声也进入误差标签，低参数网络用于学习确定性部分；需检查校准没有损害噪声底。

推理函数完全不使用带通滤波、不读取理想输入、不依赖 `fin`；`fin` 只用于训练标签和评估。双音推理同样不需要两个音调的频率，但评估函数需要。

通用 17-tap 导数设计覆盖到 0.8×Nyquist（400 MHz）。你的 496.09375 MHz 已改用用户配置中的 513 taps；近 Nyquist 的采样失真高次谐波会混叠，数字导数与连续时间采样误差的对应关系仍需在真实数据上确认。不要直接套用到超 Nyquist 的输入。把记录的 fs、满量程、位数、导数设计或量化方式改掉后要重新训练。

这是离线实现，中心导数滤波舍弃两端 8 点。若做因果实时硬件，导数滤波产生 8 个采样周期延迟，需要同样延迟 d 支路；带通只在离线训练中出现。

## 指标与结果解释

`adc_nn_metrics` 同时拟合 DC 与已知基波（双音时拟合两个基波），剩余信号用于计算 SNDR；SFDR 为最大 Hann-window 残差频谱幅度相对最大基波幅度。这是明确给出的诊断算法，和论文/仪器的指标口径可能不同。FFT 图统一按校准前基波归一化，避免各自归一化掩盖幅度变化。

检查：未见过单音的 SNDR/SFDR，双音 IM3，基波幅度变化，校准是否引入新杂散，低失真点是否被损害。不要只看训练 MSE。12-bit 理想满幅正弦量化 SNR 约 74 dB；强失真被消除后通常接近量化噪声限制。校准模型不会凭空恢复丢失的信息。

如果你的开关电容网络已经很线性，输出失真远低于 12-bit 量化噪声，NN 的 SNDR 改善可能很小，这是合理结果。先确认失真和采样提取正确，再考虑用低 VDD/更高频率等可控条件展示校准；报告必须写明条件。不要为了得到目标 dB 数字人为调数据。

## 论文之外的实现选择与尚未完成的部分

已实现：特征增强、3 tanh+线性支路、单音带通误差标签、Adam、训练集归一化、独立验证早停、冻结推理、量化、单音/双音评估、CSV 接口。

未实现：作者原始训练配置与权重、反复剪枝及对称约束、原芯片 10 样片统计、温度传感器量化、LUT 及定点部署、65 nm 面积功耗验证。你的电路数据到位后还需实际训练和检查泛化，代码准备完成不等于你的电路已经校准成功。

MATLAB 自动微分/优化接口依据：
- https://www.mathworks.com/help/deeplearning/ref/dlarray.dlgradient.html
- https://www.mathworks.com/help/deeplearning/ref/adamupdate.html
