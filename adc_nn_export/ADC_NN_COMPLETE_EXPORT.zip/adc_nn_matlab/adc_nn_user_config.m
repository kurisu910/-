function cfg = adc_nn_user_config()
% User's 1-GS/s differential sampler, close-to-Nyquist first experiment.
cfg = adc_nn_config();
cfg.vmin = -0.6; cfg.vmax = 0.6; % Vp-Vn OUTPUT full-scale: 1.2 Vpp.
cfg.inputFullScaleVpp = 0.6;
cfg.outputFullScaleVpp = 1.2;
cfg.commonModeV = 0.5;
cfg.temperatureC = 25;
cfg.initialFinHz = 127*cfg.fs/256; % 496.09375 MHz.
% Near Nyquist adaptation, not the paper's 17-tap implementation.
cfg.derivativeTaps = 513;
cfg.derivativeBand = 0.995;
cfg.labelHalfWidthHz = 0.75e6;    % stays below the 500-MHz Nyquist edge.
end
