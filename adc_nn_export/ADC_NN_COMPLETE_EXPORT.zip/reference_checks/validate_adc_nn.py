"""Independent numerical checks for the delivered MATLAB algorithm.
This does not execute MATLAB, and cannot validate Deep Learning Toolbox runtime.
"""
from pathlib import Path
import json
import numpy as np
from scipy.signal import convolve

rng = np.random.default_rng(42)
FS = 1e9
N = 8192

def derivative_filter():
    k = np.arange(1,9)
    w = np.linspace(1e-5,.8*np.pi,512)
    g = np.linalg.lstsq(2*np.sin(w[:,None]*k),w,rcond=None)[0]
    return np.r_[g[::-1],0,-g]

H = derivative_filter()

def sampler(fin, amps, temp):
    fin,amps=np.atleast_1d(fin),np.atleast_1d(amps)
    n=np.arange(N+256)
    ts=n/FS
    s=32
    dt=.5/FS/s
    u=ts[:,None]-.5/FS+(np.arange(s)+.5)*dt
    vi=np.sum(amps[None,None,:]*np.sin(2*np.pi*u[:,:,None]*fin[None,None,:]+.23),axis=2)
    tau=(.025/FS)*(1+.7*np.exp(-(temp-25)/110)*vi**2)
    a=np.exp(-dt/tau).ravel()
    b=((1-np.exp(-dt/tau))*vi).ravel()
    z=np.empty_like(a); last=0.
    for i in range(len(a)):
        last=a[i]*last+b[i]; z[i]=last
    held=z.reshape(-1,s)[:,-1][256:]+2e-5*rng.normal(size=N)
    assert np.all(abs(held)<1)
    code=np.floor((held+1)/2*4096)
    d=-1+(code+.5)*2/4096
    return {'d':d,'fin':fin,'T':temp}

def features(r):
    d=r['d']; dd=convolve(d,H,mode='same')
    return np.vstack([d,dd]+[dd*d**k for k in range(1,6)]+[np.ones(N)*r['T']])

def target(r):
    f0=float(r['fin'][0]); k=np.arange(-512,513)
    fl=(f0-5e6)/FS; fh=(f0+5e6)/FS
    h=2*fh*np.sinc(2*fh*k)-2*fl*np.sinc(2*fl*k)
    h*=.54+.46*np.cos(np.pi*k/512)
    h/=np.sum(h*np.cos(2*np.pi*f0/FS*k))
    for order in range(2,6):
        fa=abs((order*f0+FS/2)%FS-FS/2)
        assert abs(np.sum(h*np.exp(-2j*np.pi*fa/FS*k)))<.01
    return r['d']-(np.mean(r['d'])+convolve(r['d']-np.mean(r['d']),h,mode='same'))

def metric(d,fin):
    n=np.arange(len(d)); cols=[np.ones(len(d))]
    for f in fin:
        cols.extend([np.sin(2*np.pi*f/FS*n),np.cos(2*np.pi*f/FS*n)])
    B=np.array(cols).T
    c=np.linalg.lstsq(B,d,rcond=None)[0]
    signal=B[:,1:]@c[1:]; residual=d-B@c
    sndr=10*np.log10(np.mean(signal**2)/np.mean(residual**2))
    w=.5-.5*np.cos(2*np.pi*n/len(n))
    spectrum=2*abs(np.fft.rfft(residual*w))/np.sum(w); spectrum[0]=0
    if len(n)%2==0: spectrum[-1]/=2
    amp=np.hypot(c[1::2],c[2::2])
    sfdr=20*np.log10(max(amp)/max(spectrum))
    return {'SNDR_dB':float(sndr),'SFDR_dB':float(sfdr),'amplitudes':amp.tolist()}

def forward(p,X):
    S=np.tanh(p['W']@X+p['b'])
    return p['v'].T@S+p['a'].T@X+p['c'],S

def loss_grad(p,X,Y,l2=1e-5):
    y,S=forward(p,X); delta=2*(y-Y)/X.shape[1]
    reg=l2*sum(np.sum(p[k]**2) for k in ['W','v','a'])
    loss=float(np.mean((y-Y)**2)+reg)
    dz=p['v']@delta*(1-S**2)
    g={'W':dz@X.T+2*l2*p['W'],'b':dz.sum(axis=1,keepdims=True),
       'v':S@delta.T+2*l2*p['v'],'a':X@delta.T+2*l2*p['a'],
       'c':delta.sum().reshape(1,1)}
    return loss,g

def gradient_check():
    p={k:rng.normal(size=s)*.2 for k,s in
       {'W':(3,8),'b':(3,1),'v':(3,1),'a':(8,1),'c':(1,1)}.items()}
    X=rng.normal(size=(8,21));Y=rng.normal(size=(1,21))
    loss,g=loss_grad(p,X,Y); worst=0
    for k in p:
        for idx in np.ndindex(p[k].shape):
            old=p[k][idx]; eps=1e-6
            p[k][idx]=old+eps; plus=loss_grad(p,X,Y)[0]
            p[k][idx]=old-eps; minus=loss_grad(p,X,Y)[0]
            p[k][idx]=old
            worst=max(worst,abs((plus-minus)/(2*eps)-g[k][idx]))
    assert worst<1e-7
    return worst

report={'MATLAB_executed':False,'gradient_max_abs_error':gradient_check()}
w=2*np.pi*np.array([.05,.1,.2,.3,.35,.4])
k=np.arange(-8,9)
response=np.array([np.sum(H*np.exp(-1j*a*k))/(1j*a) for a in w])
report['derivative_gain_ratios']=response.real.tolist()
assert np.max(abs(response-1))<.01
# Baseline: no distortion should not be "corrected" by an erroneous label filter.
clean={'d':.8*np.sin(2*np.pi*701/N*np.arange(N)+.3),'fin':np.array([701*FS/N]),'T':25}
clean_error=target(clean)[512:-512]
assert max(abs(clean_error))<1e-11
report['clean_sine_label_max_error']=float(max(abs(clean_error)))
ideal=-1+(np.floor((clean['d']+1)/2*4096)+.5)*2/4096
report['ideal_quantized_sine']=metric(ideal,clean['fin'])
assert 69<report['ideal_quantized_sine']['SNDR_dB']<75

train=[sampler(b*FS/N,a,t) for t in [-20,80] for a in [.45,.8] for b in [701,1231,2003]]
val=sampler(1601*FS/N,.65,25)
test=sampler(1777*FS/N,.72,40)
two=sampler(np.array([1373,1699])*FS/N,[.35,.35],40)
Xt=np.concatenate([features(r)[:,512:-512] for r in train],axis=1)
Yt=np.concatenate([target(r)[None,512:-512] for r in train],axis=1)
Xv=features(val)[:,512:-512];Yv=target(val)[None,512:-512]
mu=Xt.mean(axis=1,keepdims=True);sd=Xt.std(axis=1,keepdims=True,ddof=1);sd[sd<1e-10]=1
es=max(Yt.std(ddof=1),1e-6)
Xt=(Xt-mu)/sd;Xv=(Xv-mu)/sd;Yt=Yt/es;Yv=Yv/es
A=np.vstack([Xt,np.ones(Xt.shape[1])]);reg=np.eye(9)*1e-4;reg[-1,-1]=0
beta=np.linalg.solve(A@A.T+reg,A@Yt.T)
p={'W':.3*rng.normal(size=(3,8)),'b':.1*rng.normal(size=(3,1)),
   'v':.01*rng.normal(size=(3,1)),'a':beta[:8],'c':beta[8:]}
avg={k:np.zeros_like(v) for k,v in p.items()};sq={k:v.copy() for k,v in avg.items()}
best={k:v.copy() for k,v in p.items()};bestloss=np.mean((forward(p,Xv)[0]-Yv)**2)
report['initial_validation_MSE']=float(bestloss*es**2)
iteration=0;stale=0;bestepoch=0
train_history=[];validation_history=[]
for epoch in range(1,201):
    perm=rng.permutation(Xt.shape[1])
    for start in range(0,len(perm),2048):
        idx=perm[start:start+2048];_,g=loss_grad(p,Xt[:,idx],Yt[:,idx]);iteration+=1
        for k in p:
            avg[k]=.9*avg[k]+.1*g[k];sq[k]=.999*sq[k]+.001*g[k]**2
            p[k]-=.002*(avg[k]/(1-.9**iteration))/(np.sqrt(sq[k]/(1-.999**iteration))+1e-8)
    loss=np.mean((forward(p,Xv)[0]-Yv)**2)
    train_history.append(float(np.mean((forward(p,Xt)[0]-Yt)**2)*es**2))
    validation_history.append(float(loss*es**2))
    if loss<bestloss:
        bestloss=loss;best={k:v.copy() for k,v in p.items()};stale=0;bestepoch=epoch
    else:stale+=1
    if epoch%25==0: print('epoch',epoch,'validation',loss*es**2,flush=True)
    if stale>=30:break
report.update(best_epoch=bestepoch,epochs_run=epoch,validation_MSE=float(bestloss*es**2))
report['training_curve']={'train_MSE':train_history,'validation_MSE':validation_history}
for name,r in [('unseen_single_tone',test),('unseen_two_tone',two)]:
    X=(features(r)-mu)/sd;error=es*forward(best,X)[0][0]
    raw=r['d'][512:-512];cal=(r['d']-error)[512:-512]
    before=metric(raw,r['fin']);after=metric(cal,r['fin'])
    report[name]={'before':before,'after':after,'delta_SNDR':after['SNDR_dB']-before['SNDR_dB'],
                  'delta_SFDR':after['SFDR_dB']-before['SFDR_dB']}
    if name=='unseen_single_tone':
        np.savez('/workspace/work/adc_nn_reference_signals.npz',raw=raw,cal=cal,fs=FS,
                 fin=r['fin'],label=target(r)[512:-512],predicted_error=error[512:-512])
assert report['unseen_single_tone']['delta_SFDR']>0
Path('/workspace/work/adc_nn_validation.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
