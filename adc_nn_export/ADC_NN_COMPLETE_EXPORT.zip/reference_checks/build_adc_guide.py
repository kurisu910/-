from pathlib import Path
import base64, json, html
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, PageBreak, Table, TableStyle
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.colors import HexColor, white
from reportlab.lib.enums import TA_LEFT

ROOT=Path('/workspace/work/adc_nn_matlab')
ASSETS=ROOT/'guide_assets'; ASSETS.mkdir(exist_ok=True)
FONT='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
fp=FontProperties(fname=FONT)
plt.rcParams.update({'font.family':fp.get_name(),'font.size':11,'axes.unicode_minus':False})
TEAL='#0d9488';BLUE='#2563eb';PURPLE='#7c3aed';INK='#142b43';MUTED='#536779'

def txt(ax,x,y,s,size=11,color=INK,ha='center'):
    return ax.text(x,y,s,fontsize=size,color=color,ha=ha,va='center',fontproperties=fp)

def box(ax,x,y,w,h,label,color=TEAL):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.03,rounding_size=0.10',
                              linewidth=1.5,edgecolor=color,facecolor=color+'0d'))
    txt(ax,x+w/2,y+h/2,label)

def arrow(ax,x1,y1,x2,y2,color=MUTED):
    ax.add_patch(FancyArrowPatch((x1,y1),(x2,y2),arrowstyle='-|>',mutation_scale=13,
                               linewidth=1.5,color=color))

def diagram(name,width=11,height=3.3):
    fig,ax=plt.subplots(figsize=(width,height));fig.patch.set_facecolor('white')
    ax.set_xlim(0,11);ax.set_ylim(0,height);ax.axis('off')
    return fig,ax

def save(fig,name):
    path=ASSETS/f'{name}.png';fig.savefig(path,dpi=180,bbox_inches='tight',facecolor='white')
    plt.close(fig);return path

fig,ax=diagram('overview')
labels=['Virtuoso 采样电路\n每周期读 Vp、Vn','理想 12-bit 量化\n得到数字输出 d','特征增强\n8 个输入量','浅层 NN\n估计误差 ê']
for i,label in enumerate(labels):
    x=.15+i*2.75;box(ax,x,1.65,2.4,1.05,label,[TEAL,BLUE,PURPLE,TEAL][i])
    if i<3:arrow(ax,x+2.42,2.18,x+2.70,2.18)
box(ax,7.55,.15,3.10,.85,'校准结果：d_cal = d − ê',BLUE)
arrow(ax,9.62,1.62,9.62,1.05)
arrow(ax,4.15,1.62,4.15,.58);arrow(ax,4.15,.58,7.45,.58)
txt(ax,5.65,.90,'原始 d 保留一条支路',size=10)
save(fig,'01_overview')

fig,axs=plt.subplots(2,1,figsize=(10.2,3.6),sharex=True)
n=np.arange(300);d=.65*np.sin(2*np.pi*n/100);dd=.65*2*np.pi/100*np.cos(2*np.pi*n/100)
axs[0].plot(n,d,color=BLUE,lw=2);axs[1].plot(n,dd,color=TEAL,lw=2)
for ax,label in zip(axs,['数字输出 d','每采样点变化量 d′']):
    ax.set_ylabel(label,fontproperties=fp);ax.grid(alpha=.2)
    ax.spines[['top','right']].set_visible(False)
for a in [8,42]:
    axs[0].plot(a,d[a],'o',color=PURPLE);axs[1].plot(a,dd[a],'o',color=PURPLE)
axs[0].annotate('相同电压，运动方向不同',xy=(42,d[42]),xytext=(130,.65),
                arrowprops={'arrowstyle':'->','color':PURPLE},fontproperties=fp,color=PURPLE)
axs[1].set_xlabel('采样点序号 n（示意波形）',fontproperties=fp)
fig.tight_layout();save(fig,'02_derivative')

fig,ax=diagram('network',height=3.6)
box(ax,.2,.65,2.5,2.2,'8 维输入 X\n\nd、d′、d′d … d′d⁵\n温度 T',BLUE)
for y,label,color in [(3.1,'tanh / s₂',PURPLE),(2.35,'tanh / s₃',PURPLE),
                      (1.6,'tanh / s₄',PURPLE),(.60,'线性支路 / s₁',TEAL)]:
    box(ax,4.2,y-.28,2.15,.56,label,color);arrow(ax,2.75,1.75,4.15,y,color)
    arrow(ax,6.40,y,8.35,1.75,color)
box(ax,8.4,1.2,2.3,1.10,'加权求和 / s₅\n输出误差 ê',BLUE)
txt(ax,5.30,3.55,'3 个非线性单元',size=10,color=PURPLE)
save(fig,'03_network')

fig,ax=diagram('training',height=4.1)
box(ax,.1,2.9,2.25,.8,'单音 ADC 输出 d',BLUE)
box(ax,3.0,2.9,2.4,.8,'带通保留基波\n生成参考 d_ref',TEAL)
box(ax,6.2,2.9,3.3,.8,'真实标签 e_target\n= d − d_ref',TEAL)
arrow(ax,2.4,3.3,2.95,3.3);arrow(ax,5.45,3.3,6.15,3.3)
box(ax,3.0,1.35,2.4,.8,'特征增强 + NN\n预测误差 ê',PURPLE)
box(ax,6.2,1.35,3.3,.8,'MSE 损失\n平均 (ê − e_target)²',BLUE)
arrow(ax,1.20,2.85,1.20,1.75);arrow(ax,1.20,1.75,2.95,1.75)
arrow(ax,5.45,1.75,6.15,1.75);arrow(ax,7.85,2.85,7.85,2.2)
arrow(ax,7.85,1.30,7.85,.38,PURPLE);arrow(ax,7.85,.38,4.20,.38,PURPLE)
arrow(ax,4.20,.38,4.20,1.30,PURPLE)
txt(ax,6.05,.70,'反向传播 + Adam 更新权重',size=11,color=PURPLE)
save(fig,'04_training')

fig,ax=diagram('splits',height=3.1)
for i,(title,body,color) in enumerate([
    ('训练集','用于更新权重\n3 频率 × 2 幅度',TEAL),
    ('验证集','选最佳模型 / 早停\n新的频率、幅度',PURPLE),
    ('测试集','训练结束后才评估\n未见单音 + 双音',BLUE)]):
    x=.25+i*3.65;box(ax,x,.8,3.2,1.8,title+'\n\n'+body,color)
txt(ax,5.5,.28,'按整条电路波形划分；不要从同一正弦记录随机抽点充当独立测试',size=10)
save(fig,'05_splits')

check=json.loads(Path('/workspace/work/adc_nn_validation.json').read_text())
fig,ax=plt.subplots(figsize=(10.2,3.4))
tr=check['training_curve']['train_MSE'];va=check['training_curve']['validation_MSE'];epochs=np.arange(1,len(tr)+1)
ax.semilogy(epochs,tr,label='训练集',color=TEAL);ax.semilogy(epochs,va,label='验证集',color=PURPLE)
be=check['best_epoch'];ax.axvline(be,color=BLUE,ls='--',lw=1.3)
ax.annotate(f'保存验证误差最小的第 {be} 轮',xy=(be,va[be-1]),xytext=(12,va[be-1]*2),
            arrowprops={'arrowstyle':'->','color':BLUE},fontproperties=fp,color=BLUE)
ax.set_xlabel('训练轮数 Epoch',fontproperties=fp);ax.set_ylabel('误差 MSE（对数刻度）',fontproperties=fp)
ax.legend(prop=fp);ax.grid(alpha=.2);ax.spines[['top','right']].set_visible(False)
fig.tight_layout();save(fig,'06_curve')

sig=np.load('/workspace/work/adc_nn_reference_signals.npz')
fig,ax=plt.subplots(figsize=(10.2,3.4))
raw=sig['raw'];cal=sig['cal'];L=len(raw);w=.5-.5*np.cos(2*np.pi*np.arange(L)/L)
a=2*abs(np.fft.rfft((raw-raw.mean())*w))/w.sum();b=2*abs(np.fft.rfft((cal-cal.mean())*w))/w.sum()
f=np.fft.rfftfreq(L,1/float(sig['fs']))/1e6;ref=a[1:].max()
ax.plot(f,20*np.log10(np.maximum(a/ref,1e-12)),label='校准前',color=BLUE,lw=1)
ax.plot(f,20*np.log10(np.maximum(b/ref,1e-12)),label='校准后',color=TEAL,lw=1)
ax.set_ylim(-115,5);ax.set_xlim(0,500)
ax.set_xlabel('频率 / MHz',fontproperties=fp);ax.set_ylabel('幅度 / dBc（统一参考）',fontproperties=fp)
ax.legend(prop=fp);ax.grid(alpha=.2);fig.tight_layout();save(fig,'07_spectrum')

fig,ax=diagram('sampling',height=2.75)
for i in range(3):
    x=.6+3.25*i
    ax.fill_between([x,x+1.55],.75,2.25,color=BLUE,alpha=.07)
    ax.fill_between([x+1.55,x+3.1],.75,2.25,color=TEAL,alpha=.09)
    txt(ax,x+.77,1.65,'跟踪',color=BLUE);txt(ax,x+2.32,1.65,'保持',color=TEAL)
    ax.plot(x+2.5,1.05,'o',color=PURPLE);txt(ax,x+2.5,.42,'读一次',size=10,color=PURPLE)
    if i<2:arrow(ax,x+2.5,.95,x+5.75,.95)
txt(ax,5.55,2.55,'1 GS/s：每个周期 1 ns；在相同的稳定保持相位取样',size=12)
save(fig,'08_sampling')

PAGES=[]
def page(title,subtitle,parts):PAGES.append({'title':title,'subtitle':subtitle,'parts':parts})
def p(s):return ('p',s)
def h(s):return ('h',s)
def figpart(name,caption,height=145):return ('fig',name,caption,height)
def table(rows):return ('table',rows)
def code(s):return ('code',s)

page('01 / 训练到底在做什么？','从你的采样电路，到一个能够估计误差的小函数',[
p('你已有 1 GS/s 差分晶体管级采样网络。接下来不会让 AI 修改网表，而是用电路产生的数据，训练一个数字后校正函数。网络每次回答：这个采样点应该减去多少误差？'),
figpart('01_overview','图 1：接入你现有电路的完整链路。量化步骤由 MATLAB 补上。',155),
h('训练前不知道的东西，叫作“权重”'),
p('网络是一个带参数的数学函数 ê=f(X;θ)。X 是当前数字输出、输出变化量及温度等输入；θ 是 39 个可以调整的数值。训练的工作就是用数据找到这些数值。训练完成后固定它们。'),
table([['词语','在你的实验中是什么意思'],['输入 / 特征 X','网络用来判断误差的 8 个量'],['标签 e_target','训练时提供的“应该预测多少误差”'],['权重 / 参数 θ','函数里的系数，通过训练调整'],['推理 / 校准','权重固定后，给新数据计算误差并减掉']]),
p('一个示意采样点：d=0.420，参考值为 0.415，所以标签误差为 0.005。若网络预测 ê=0.004，校准结果就是 0.416，尚余 0.001 的误差。这里数值均为归一化单位，不是伏特。'),
p('代码和本文说明是依据论文方法写的独立实现，不是作者发布的程序。演示结果来自合成 RC 数据；尚未用你的真实电路数据训练。')])

page('02 / 先准备能训练的数据','一条 Virtuoso 波形，变成很多组“输入 + 标签”',[
figpart('08_sampling','图 2：每周期只读取一对稳定保持电压。具体时钟相位按你的电路确定。',115),
p('导出 time_s、vp_v、vn_v，先去掉启动过程。差分保持电压为 vp−vn。每条记录只包含一个输入频率、幅度和温度，建议取得 8192 个有效样本；1 GS/s 下相当于 8.192 μs 的样本窗口。'),
h('为什么还要理想量化？'),
p('采样网络输出仍是模拟电压。论文的网络处理 ADC 数字输出，所以先加 12-bit 理想量化。如果差分范围是 −0.5 至 +0.5 V，步长为 1 V/4096≈244 μV。这只是占位范围，必须换成你的电路范围。'),
table([['数据','应当是什么'],['time_s','每周期一个样本，间隔 1 ns；单位秒'],['vp_v、vn_v','同一时刻的正、负保持电压；单位伏特'],['fin_Hz','实际施加的单音频率；单位 Hz'],['temperature_C','该次仿真的温度；单位 °C']]),
p('程序把量化后的等效电压按固定满量程缩放为 d，通常在 −1 到 +1 之间。这样高次幂和 tanh 输入的数值更容易处理。不能为每条波形各自缩放满量程，否则网络会失去幅度差异。'),
code("r = adc_nn_record(tHeld, vpHeld, vnHeld, 25, fin, cfg, 'train_01');"),
p('如果你已经仿真了后续 ADC 并有数字码，先按其转换关系还原等效电压，设置 quantize=false，避免重复量化。')])

page('03 / 为什么要给网络 8 个输入？','把电路知识提前告诉网络，减少需要学习的东西',[
figpart('02_derivative','图 3：同一电压可能处于上升或下降过程；采样动态误差可能不同。',160),
p('只给 d，网络无法区分“正在上升的这个电压”和“正在下降的这个电压”。采样开关电阻与电容共同产生动态误差，因此还给它 d′，即输出在相邻采样时刻之间变化有多快。'),
h('论文的特征增强'),
p('8 维输入是 [d, d′, d′d, d′d², d′d³, d′d⁴, d′d⁵, T]。这些乘积不是网络学习出来的，是程序按论文式（6）提前计算的，用来描述“变化速度 × 电压相关非线性”。'),
p('d′ 由 17-tap 反对称 FIR 求得。这里用“每采样点变化量”，不乘 10⁹ 得到每秒导数；之后只用训练集的均值和标准差统一标准化。验证及测试沿用同一套标准化参数。'),
code('[X, idx] = adc_nn_features(r, cfg);'),
p('这些特征只需数字输出和温度，不需要读取晶体管内部电流。若第一轮只仿真 25°C，温度是常数，网络不能学到温度变化规律；后续增加温度数据后重新训练。')])

page('04 / 神经网络内部是什么？','3 个 tanh 单元、一条线性支路、一次加权求和',[
figpart('03_network','图 4：对应论文 s₁ 至 s₅ 的函数结构；不是 5 个隐藏层神经元。',160),
p('每个非线性单元先把输入乘以权重并相加，再加一个偏置，最后经过 tanh。tanh 是一个平滑的 S 形数学函数，用于表达输入与误差之间的非线性关系。'),
code('z = W*X + b;\nnonlinear = tanh(z);\nê = errorScale * (v\'*nonlinear + a\'*X + c);'),
p('W、b 决定 3 个非线性单元如何响应输入；v 决定它们对输出的贡献；a 是线性支路的系数；c 是输出偏置。代码把线性支路的输出增益折入 a，表达能力保持一致，共 39 个可训练参数。'),
h('“学习”就是调整这些系数'),
p('一个简化示意：某单元收到 d=0.4、d′=0.05，若系数为 1.2、−0.8，偏置为 0.1，那么内部值为 1.2×0.4−0.8×0.05+0.1=0.54，tanh 后约为 0.493。这些系数仅为解释用，真实系数由训练得到。'),
p('你无需手工算每个参数如何变化。Deep Learning Toolbox 用自动微分计算梯度，Adam 按梯度更新权重。代码未实施作者最终的对称约束和反复剪枝流程。')])

page('05 / 标签、损失与更新怎样连接？','这是训练发生的地方；校准时不再生成标签',[
figpart('04_training','图 5：上方生成误差标签，下方预测误差，比较后更新权重。',180),
p('训练只用已知频率的单音。数字输出 d 包含基波、谐波及噪声。带通滤波保留基波，得到参考 d_ref；标签为 e_target=d−d_ref。网络预测 ê，损失为平均 (ê−e_target)²。'),
p('带通必须在基波处保持单位增益，并对齐时间。否则错误的幅度或延迟会被当成 ADC 失真。本实现使用中心卷积与边界裁剪处理延迟，不让滤波开头和结尾的伪差参与训练。'),
h('一次训练循环'),
p('① 取一批输入/标签；② 计算预测误差；③ 计算 MSE；④ 自动微分求梯度；⑤ Adam 更新参数；⑥ 换下一批数据，重复。一个 epoch 是把全部训练样本看一遍，mini-batch 是一次用于更新的一小批样本，默认最多 2048 个。'),
code('[loss, grad] = dlfeval(@gradients, ...);\n[p, avg, avgSq] = adamupdate(p, grad, ...);'),
p('这里的参考只保留实际输出的基波，并不等于无误差的真实输入。这个目标主要用于抑制谐波，不能据此恢复绝对增益/相位或把随机噪声全部消除。滤波器只在训练阶段使用。')])

page('06 / 怎样知道训练真的有效？','训练集用于学习，验证集用于选择，测试集用于独立评估',[
figpart('05_splits','图 6：按整条波形或输入条件划分三组数据。',130),
figpart('06_curve','图 7：NumPy 参考实现的合成 RC 数据检查曲线；不是 MATLAB 原生运行或你的电路结果。',155),
p('训练误差低，只说明网络适应了已看过的数据。验证集不更新权重，用来选择模型。程序保留验证 MSE 最小的一轮，连续 30 轮没有改善就早停；这张检查图中最佳是第 4 轮，不是最后一轮。'),
p('最终测试再换一组没有参与模型选择的频率/幅度。还要用单音训练的模型测试双音，观察互调分量。第一次实验可以固定温度，成功后再加入温度扫描。'),
p('两条曲线不一定平滑，也不必一直下降。以独立数据上的 FFT、SNDR、SFDR、基波幅度和噪声底作为最终判断。训练 MSE 与 SNDR 不是同一个指标。')])

page('07 / 训练结束后，怎样校准新数据？','权重冻结，输入新波形，直接减去预测误差',[
figpart('07_spectrum','图 8：独立合成 RC 单音测试的频谱示例；不能替代你的 Virtuoso 实验。',160),
p('推理只做：新数字输出 → 相同特征/标准化 → 已训练的固定函数 → ê → d_cal=d−ê。它不再用基波滤波标签，不看理想输入，也不用输入频率来计算校正。fin 仅供评估函数识别基波。'),
code("[model, history] = adc_nn_train(train, validation, cfg);\nout = adc_nn_predict(model, test);\nreport = adc_nn_evaluate(model, test, true);\nsave('my_adc_calibrator.mat', 'model', 'history');"),
p('out.dCal 是校准后的归一化数字信号；out.vCal 是差分等效电压；out.correctedCode 可以有小数。不要立刻重新舍入到 12 bit，否则会损失细小的数字校正。'),
h('必须检查的现象'),
p('谐波/互调是否下降；未见过的输入是否仍有效；基波是否被明显削弱；有没有新杂散；低失真条件是否被损害。一个已经接近理想量化噪声的电路，NN 的 SNDR 改善可以很小。'),
p('报告应区分：原论文的实测结果、代码的合成演示结果、你真实晶体管级电路的数据结果。本文尚未把后两者混为一谈。')])

page('08 / 你现在按什么顺序操作？','先跑通演示，再跑真实波形，最后扩展实验',[
table([['顺序','动作','对应文件'],['1','解压，运行合成演示','demo_adc_nn.m'],['2','确认差分满量程、位数','adc_nn_config.m'],['3','每周期读取稳定保持电压','adc_nn_sample_waveform.m'],['4','准备 6 训练 + 1 验证 + 1 测试记录','manifest_template.csv'],['5','运行真实数据训练','run_virtuoso_data.m'],['6','查看 FFT 和指标，保存模型','adc_nn_evaluate.m']]),
code("[model, history, results] = demo_adc_nn;\n% 真实数据准备好后：\n[model, history, results] = run_virtuoso_data('manifest.csv');"),
p('1 GS/s、8192 点的起始建议：训练频率约 85.571、150.269、244.507 MHz，各两个幅度；验证约 195.435 MHz；测试约 216.919 MHz。精确相干频率与 CSV 示例见 README。'),
h('常见问题，从数据开始排查'),
table([['现象','优先检查'],['量化溢出','vmin/vmax 是否是差分满量程；输入峰值是否过大'],['训练不收敛','取样相位、启动数据、单位、标签延迟、标准化'],['训练有效，测试变差','是否只训练一个条件；是否测试超出训练范围'],['几乎没有性能改善','电路是否已很线性；是否已由量化/噪声限制'],['标签拒绝某频率','高次谐波可能混叠到基波；换频率或改滤波器']]),
p('当前检查：14 个 .m 文件通过语法解析；对应数学流程已在 NumPy 检查。环境没有 MATLAB，所以未实际执行 Deep Learning Toolbox；先在你的 MATLAB 运行 demo，遇到报错把完整信息发来。详见 VALIDATION.md。'),
p('本文依据：Molendijk 等，TCAS-I 2026，式（6）、Fig. 3/4 与 Section III；MATLAB 自动微分与 Adam 接口依据 MathWorks 官方文档。代码 README 给出了链接和所有实现差异。')])

page('09 / 按你的电路参数开始','0.6 Vpp 输入、1.2 Vpp 输出、0.5 V 共模、496.09375 MHz',[
p('前面几页用通用配置解释方法。这一页对应你刚给出的实际参数；run_virtuoso_data 已改用 adc_nn_user_config。温度先取 25°C，保持 12-bit 理想量化。'),
table([['参数','实际配置'],['输入差分满量程','0.6 Vpp：若以 0 V 为中心，输入范围为 ±0.3 V'],['输出差分满量程','1.2 Vpp：量化 Vp−Vn，范围为 ±0.6 V'],['共模电压','0.5 V；不要作为差分范围的中心'],['采样率 / 输入频率','1 GHz / 127×1 GHz÷256 = 496.09375 MHz'],['12-bit 输出量化步长','1.2 V÷4096 ≈ 292.969 μV']]),
h('接近 Nyquist，需要改变滤波器'),
p('Nyquist 是 500 MHz，你的输入只比它低 3.90625 MHz。通用 17-tap 导数滤波器在此点幅度约为理想值的 6.18%，因此用户配置改为 513 taps，数值检查幅度误差约 0.044%。标签带通半宽缩到 0.75 MHz，以免跨过边界。'),
p('这是一项近 Nyquist 算法适配，不能声称复现了论文 17-tap 的面积、功耗或延迟。此滤波器的因果延迟是 256 个周期，离线训练用时间对齐处理。真实电路是否能有效校准仍要测试。'),
h('第一轮：固定频率、固定温度、改变幅度'),
table([['数据集','满量程比例','差分输入 Vpp'],['训练','45%、65%、85%','0.27、0.39、0.51 V'],['验证','70%','0.42 V'],['测试','80%','0.48 V']]),
code("[model, history, results] = ...\n    run_virtuoso_data('manifest_user_496MHz.csv');"),
p('先按 manifest 准备五份独立电路波形，各取 8192 个有效保持样本。这一轮只验证幅度泛化；若要验证频率、温度或双音，必须补相应数据。输入输出的两倍增益也不会由基波标签自动消除。')])

pdfmetrics.registerFont(UnicodeCIDFont('STSong-Light'))
def pdf_safe(s):
    return str(s).replace('−','-').replace('·',' / ')
styles={
    'body':ParagraphStyle('body',fontName='STSong-Light',fontSize=10.5,leading=16.5,
                          textColor=HexColor(INK),wordWrap='CJK',spaceAfter=9),
    'h':ParagraphStyle('h',fontName='STSong-Light',fontSize=13,leading=19,
                       textColor=HexColor(TEAL),wordWrap='CJK',spaceBefore=5,spaceAfter=7),
    'title':ParagraphStyle('title',fontName='STSong-Light',fontSize=21,leading=29,
                           textColor=HexColor(INK),wordWrap='CJK',spaceAfter=5),
    'subtitle':ParagraphStyle('subtitle',fontName='STSong-Light',fontSize=11,leading=17,
                              textColor=HexColor(MUTED),wordWrap='CJK',spaceAfter=14),
    'caption':ParagraphStyle('caption',fontName='STSong-Light',fontSize=8.5,leading=13,
                             textColor=HexColor(MUTED),wordWrap='CJK',spaceAfter=10),
    'code':ParagraphStyle('code',fontName='Courier',fontSize=8.2,leading=12,
                          textColor=HexColor(INK),backColor=HexColor('#eef4f8'),
                          borderPadding=9,spaceBefore=4,spaceAfter=12),
    'cell':ParagraphStyle('cell',fontName='STSong-Light',fontSize=9.2,leading=14,
                          textColor=HexColor(INK),wordWrap='CJK')}

def footer(c,doc):
    c.saveState();c.setStrokeColor(HexColor('#d8e3eb'));c.line(45,37,550,37)
    c.setFont('STSong-Light',8);c.setFillColor(HexColor(MUTED))
    c.drawString(45,24,'1 GS/s 差分采样网络 | 浅层 NN 后校正 | 初学说明')
    c.drawRightString(550,24,str(doc.page));c.restoreState()

story=[]
for i,pg in enumerate(PAGES):
    if i:story.append(PageBreak())
    story.extend([Paragraph(pdf_safe(pg['title']),styles['title']),Paragraph(pdf_safe(pg['subtitle']),styles['subtitle'])])
    for part in pg['parts']:
        typ=part[0]
        if typ in ['p','h']:story.append(Paragraph(html.escape(pdf_safe(part[1])),styles['body' if typ=='p' else 'h']))
        elif typ=='code':story.append(Paragraph(html.escape(pdf_safe(part[1])).replace('\n','<br/>'),styles['code']))
        elif typ=='fig':
            im=Image(str(ASSETS/(part[1]+'.png')))
            scale=min(505/im.imageWidth,part[3]/im.imageHeight)
            im.drawWidth=im.imageWidth*scale;im.drawHeight=im.imageHeight*scale
            story.extend([im,Spacer(1,4),Paragraph(pdf_safe(part[2]),styles['caption'])])
        elif typ=='table':
            rows=[[Paragraph(html.escape(pdf_safe(s)),styles['cell']) for s in row] for row in part[1]]
            cols=len(rows[0]);widths=[125,380] if cols==2 else [45,245,215]
            tb=Table(rows,colWidths=widths,hAlign='LEFT')
            tb.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),HexColor('#e5f4f1')),
                ('ROWBACKGROUNDS',(0,1),(-1,-1),[white,HexColor('#f4f7fa')]),
                ('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),8),
                ('RIGHTPADDING',(0,0),(-1,-1),8),('TOPPADDING',(0,0),(-1,-1),6),
                ('BOTTOMPADDING',(0,0),(-1,-1),6)]))
            story.extend([tb,Spacer(1,12)])
doc=SimpleDocTemplate(str(ROOT/'NN训练图文说明.pdf'),pagesize=(595.28,841.89),
                     leftMargin=45,rightMargin=45,topMargin=38,bottomMargin=48,
                     title='1 GS/s 差分采样网络：神经网络训练初学说明',author='OpenAI Codex')
doc.build(story,onFirstPage=footer,onLaterPages=footer)

css='''body{margin:0;background:#edf2f7;color:#142b43;font:16px/1.85 system-ui,"Noto Sans CJK SC",sans-serif}main{max-width:940px;margin:30px auto}section{background:white;padding:35px 45px;margin:24px 0;border-radius:14px;box-shadow:0 5px 22px #132b4310}h1{font-size:28px;margin:0;color:#142b43}h2{font-size:20px;color:#0d9488}p{margin:12px 0}.subtitle,figcaption{color:#536779}figure{margin:22px 0}img{width:100%;height:auto}figcaption{font-size:13px}table{width:100%;border-collapse:collapse;font-size:14px}th,td{text-align:left;padding:12px;border-bottom:1px solid #e5ebf2}th{background:#e5f4f1}pre{padding:18px;background:#eef4f8;border-radius:8px;overflow:auto;font:13px/1.65 monospace}@media print{body{background:white}main{margin:0;max-width:none}section{box-shadow:none;margin:0;padding:15mm;break-before:page}section:first-child{break-before:auto}}'''
out=['<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>NN 训练图文说明</title><style>'+css+'</style><main>']
for pg in PAGES:
    out.append('<section><h1>'+html.escape(pg['title'])+'</h1><p class="subtitle">'+html.escape(pg['subtitle'])+'</p>')
    for part in pg['parts']:
        typ=part[0]
        if typ in ['p','h']:
            tag='p' if typ=='p' else 'h2';out.append('<'+tag+'>'+html.escape(part[1])+'</'+tag+'>')
        elif typ=='code':out.append('<pre>'+html.escape(part[1])+'</pre>')
        elif typ=='fig':
            data=base64.b64encode((ASSETS/(part[1]+'.png')).read_bytes()).decode()
            out.append('<figure><img alt="'+html.escape(part[2],quote=True)+'" src="data:image/png;base64,'+data+'"><figcaption>'+html.escape(part[2])+'</figcaption></figure>')
        elif typ=='table':
            out.append('<table>')
            for j,row in enumerate(part[1]):
                tag='th' if j==0 else 'td';out.append('<tr>'+''.join('<'+tag+'>'+html.escape(s)+'</'+tag+'>' for s in row)+'</tr>')
            out.append('</table>')
    out.append('</section>')
out.append('</main></html>')
(ROOT/'NN训练图文说明.html').write_text('\n'.join(out),encoding='utf-8')
print('Created PDF and self-contained HTML with',len(PAGES),'sections.')
